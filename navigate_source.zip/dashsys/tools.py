"""Tool implementations: execute_sql + call_api.

Both record their full input/output for the trajectory JSON.
"""

from __future__ import annotations

import json
import os
import time
from typing import Any, Dict, List, Optional, Tuple

import duckdb
import requests


# ---------------------------------------------------------------------------
# DuckDB-backed SQL tool ---------------------------------------------------
# ---------------------------------------------------------------------------

_DUCKDB_CON: Optional[duckdb.DuckDBPyConnection] = None


def _get_duckdb(snapshot_dir: str) -> duckdb.DuckDBPyConnection:
    global _DUCKDB_CON
    if _DUCKDB_CON is not None:
        return _DUCKDB_CON
    con = duckdb.connect()
    for fn in os.listdir(snapshot_dir):
        if not fn.endswith(".parquet"):
            continue
        table = fn[: -len(".parquet")]
        try:
            con.execute(
                f"CREATE OR REPLACE VIEW {table} AS "
                f"SELECT * FROM read_parquet('{snapshot_dir}/{fn}')"
            )
        except duckdb.Error:
            # Some bridge files are intentionally empty (column-less parquet
            # written by the organisers).  Create a placeholder view so the
            # table name still resolves.
            con.execute(
                f"CREATE OR REPLACE VIEW {table} AS "
                f"SELECT NULL::VARCHAR AS placeholder WHERE 1=0"
            )
    _DUCKDB_CON = con
    return con


def execute_sql(sql: str, snapshot_dir: str = "DBSnapshot",
                limit: int = 200) -> Dict[str, Any]:
    """Run a read-only SQL query.  Returns a small JSON-serialisable result."""
    t0 = time.time()
    con = _get_duckdb(snapshot_dir)
    try:
        df = con.execute(sql).fetchdf()
    except Exception as e:
        return {
            "status":   "error",
            "error":    str(e),
            "sql":      sql,
            "wall_ms":  int((time.time() - t0) * 1000),
        }
    rows = df.head(limit).to_dict(orient="records")
    return {
        "status":     "success",
        "sql":        sql,
        "row_count":  int(len(df)),
        "columns":    list(df.columns),
        "rows":       rows,
        "wall_ms":    int((time.time() - t0) * 1000),
    }


# ---------------------------------------------------------------------------
# Adobe IMS + Experience Platform API tool ---------------------------------
# ---------------------------------------------------------------------------

class AdobeApiClient:
    """Thin wrapper around platform.adobe.io that caches the IMS token."""

    IMS_URL  = "https://ims-na1.adobelogin.com/ims/token/v3"
    BASE_URL = "https://platform.adobe.io"

    def __init__(self,
                 client_id:     Optional[str] = None,
                 client_secret: Optional[str] = None,
                 ims_org:       Optional[str] = None,
                 sandbox:       Optional[str] = None,
                 timeout:       int = 30):
        self.client_id     = client_id     or os.environ["ADOBE_CLIENT_ID"]
        self.client_secret = client_secret or os.environ["ADOBE_CLIENT_SECRET"]
        self.ims_org       = ims_org       or os.environ["ADOBE_IMS_ORG"]
        self.sandbox       = sandbox       or os.environ.get("ADOBE_SANDBOX",
                                                             "external-benchmarking")
        self.timeout       = timeout
        self._token: Optional[Tuple[str, float]] = None  # (token, expiry_epoch)

    def _token_str(self) -> str:
        now = time.time()
        if self._token and self._token[1] - 60 > now:
            return self._token[0]
        resp = requests.post(
            self.IMS_URL,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            data={
                "grant_type":    "client_credentials",
                "client_id":     self.client_id,
                "client_secret": self.client_secret,
                "scope":         "openid,AdobeID,read_organizations,"
                                 "additional_info.projectedProductContext,session",
            },
            timeout=self.timeout,
        )
        resp.raise_for_status()
        j = resp.json()
        self._token = (j["access_token"], now + j.get("expires_in", 3600))
        return self._token[0]

    def call(self,
             method: str,
             url:    str,
             params: Optional[Dict] = None,
             headers: Optional[Dict] = None,
             body:   Optional[Dict] = None,
             accept: str = "application/json") -> Dict[str, Any]:
        full = url if url.startswith("http") else f"{self.BASE_URL}{url}"
        H = {
            "Authorization":   f"Bearer {self._token_str()}",
            "x-api-key":       self.client_id,
            "x-gw-ims-org-id": self.ims_org,
            "x-sandbox-name":  self.sandbox,
            "Content-Type":    "application/json",
            "Accept":          accept,
        }
        if headers:
            H.update(headers)
        t0 = time.time()
        try:
            resp = requests.request(method, full,
                                    headers=H, params=params,
                                    json=body, timeout=self.timeout)
        except Exception as e:
            return {
                "status":  "error",
                "error":   str(e),
                "method":  method,
                "url":     full,
                "params":  params,
                "wall_ms": int((time.time() - t0) * 1000),
            }
        ctype = resp.headers.get("content-type", "")
        if "json" in ctype:
            try:
                data = resp.json()
            except Exception:
                data = resp.text
        else:
            data = resp.text
        return {
            "status":      "success" if resp.ok else "error",
            "http_status": resp.status_code,
            "method":      method,
            "url":         full,
            "params":      params,
            "body":        body,
            "result":      _truncate(data),
            "wall_ms":     int((time.time() - t0) * 1000),
        }


_DEFAULT_CLIENT: Optional[AdobeApiClient] = None


def call_api(method: str,
             url:    str,
             params: Optional[Dict] = None,
             headers: Optional[Dict] = None,
             body:   Optional[Dict] = None,
             accept: str = "application/json") -> Dict[str, Any]:
    global _DEFAULT_CLIENT
    if _DEFAULT_CLIENT is None:
        _DEFAULT_CLIENT = AdobeApiClient()
    return _DEFAULT_CLIENT.call(method=method, url=url, params=params,
                                headers=headers, body=body, accept=accept)


def _truncate(obj: Any, max_chars: int = 4000) -> Any:
    """Truncate huge API responses so they don't blow up token budgets."""
    if isinstance(obj, str):
        return obj if len(obj) <= max_chars else obj[:max_chars] + "...[truncated]"
    if isinstance(obj, list):
        out = []
        used = 0
        for item in obj:
            piece = _truncate(item, max_chars - used)
            out.append(piece)
            used += len(json.dumps(piece, default=str))
            if used > max_chars:
                out.append("...[truncated]")
                break
        return out
    if isinstance(obj, dict):
        return {k: _truncate(v, max_chars) for k, v in list(obj.items())[:60]}
    return obj


# ---------------------------------------------------------------------------
# OpenAI/Anthropic-style tool schemas (the agent harness needs these) ------
# ---------------------------------------------------------------------------

TOOL_SCHEMAS = [
    {
        "type": "function",
        "function": {
            "name":        "execute_sql",
            "description": "Run a read-only SQL query against the AEP "
                           "Knowledge-Graph (DuckDB-compatible).  Use the "
                           "table+column hints in the system prompt.",
            "parameters": {
                "type": "object",
                "properties": {
                    "sql": {"type": "string", "description": "DuckDB SQL query"},
                },
                "required": ["sql"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name":        "call_api",
            "description": "Make a REST call to platform.adobe.io.  Auth headers "
                           "are injected automatically.",
            "parameters": {
                "type": "object",
                "properties": {
                    "method":  {"type": "string", "enum": ["GET", "POST", "PUT", "DELETE", "PATCH"]},
                    "url":     {"type": "string", "description": "Full URL or path (e.g. /data/foundation/...)"},
                    "params":  {"type": "object",  "additionalProperties": True},
                    "body":    {"type": "object",  "additionalProperties": True},
                    "accept":  {"type": "string"},
                },
                "required": ["method", "url"],
            },
        },
    },
]
