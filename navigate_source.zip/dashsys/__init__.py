"""DashSYS 2026 Systems Track — winning agentic NL→SQL+API system.

Public entry points:
    from dashsys.context import build_context
    from dashsys.agent   import run_agent
    from dashsys.tools   import execute_sql, call_api
"""

__version__ = "1.0.0"
