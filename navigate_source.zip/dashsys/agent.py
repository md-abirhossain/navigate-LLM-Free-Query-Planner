"""Agent loop.

The agent receives the filled system prompt + the user query, and iterates
``execute_sql``/``call_api`` until it either has enough info or hits a
configurable turn cap.  Every step is appended to a trajectory dict whose
shape matches the competition's data.json format.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .context import build_context
from .llm     import LlmClient
from .prompt  import fill_system_prompt
from .tools   import TOOL_SCHEMAS, call_api, execute_sql


# ---------------------------------------------------------------------------
@dataclass
class AgentResult:
    query:             str
    answer:            str
    trace:             List[Dict[str, Any]]
    metadata:          Dict[str, Any]
    filled_prompt:     str
    turns:             int
    total_tool_calls:  int
    total_tokens:      int
    wall_ms:           int


# ---------------------------------------------------------------------------
def _exec_tool(name: str, args: Dict, snapshot_dir: str) -> Dict[str, Any]:
    if name == "execute_sql":
        return execute_sql(sql=args["sql"], snapshot_dir=snapshot_dir)
    if name == "call_api":
        return call_api(
            method = args.get("method", "GET"),
            url    = args["url"],
            params = args.get("params"),
            body   = args.get("body"),
            accept = args.get("accept", "application/json"),
        )
    return {"status": "error", "error": f"unknown tool {name}"}


def _result_preview(tool_name: str, raw: Dict[str, Any]) -> Any:
    """Compact preview suitable for the trajectory JSON."""
    if tool_name == "execute_sql":
        if raw.get("status") == "error":
            return {"status": "error", "error": raw["error"]}
        rows = raw.get("rows", [])[:5]
        return {"status": "success", "row_count": raw["row_count"], "rows": rows}
    if tool_name == "call_api":
        r = raw.get("result")
        if isinstance(r, dict):
            keys = list(r.keys())[:8]
            return {"http_status": raw.get("http_status"),
                    "keys": keys,
                    "sample": {k: r[k] for k in keys[:3]}}
        if isinstance(r, list):
            return {"http_status": raw.get("http_status"),
                    "len": len(r),
                    "sample": r[:2]}
        return {"http_status": raw.get("http_status"),
                "text": (str(r)[:200] if r else "")}
    return raw


# ---------------------------------------------------------------------------
def run_agent(query:        str,
              snapshot_dir: str = "DBSnapshot",
              max_turns:    int = 4,
              llm:          Optional[LlmClient] = None,
              verbose:      bool = False) -> AgentResult:
    t0 = time.time()
    llm   = llm or LlmClient()
    ctx   = build_context(query)
    sys_p = fill_system_prompt(query, ctx)

    messages: List[Dict[str, Any]] = [
        {"role": "system", "content": sys_p},
        {"role": "user",   "content": query},
    ]

    trace: List[Dict[str, Any]] = []
    total_tokens = 0
    total_tool_calls = 0
    turns = 0
    final_answer: Optional[str] = None

    for turn in range(max_turns):
        turns = turn + 1
        if verbose:
            print(f"\n--- turn {turns} ---")
        # Temperature 0 keeps the agent on the deterministic plan and produces
        # consistent gold-style final answers (much better LLM-judge scores).
        resp = llm.chat(messages, tools=TOOL_SCHEMAS, temperature=0.0, max_tokens=900)
        total_tokens += resp.usage.get("total_tokens", 0)

        if resp.tool_calls:
            # Append the assistant message that includes the tool_calls so the
            # role sequence stays valid for the next turn.
            messages.append({
                "role":      "assistant",
                "content":   resp.content or "",
                "tool_calls": resp.tool_calls,
            })
            for tc in resp.tool_calls:
                fn   = tc["function"]
                name = fn["name"]
                try:
                    args = json.loads(fn["arguments"]) if isinstance(fn["arguments"], str) \
                                                       else fn["arguments"]
                except Exception:
                    args = {}
                total_tool_calls += 1
                raw  = _exec_tool(name, args, snapshot_dir)
                prev = _result_preview(name, raw)

                # Trajectory step in the required schema.
                step: Dict[str, Any] = {
                    "step":   len(trace) + 1,
                    "action": "sql_query" if name == "execute_sql" else "api_call",
                }
                if name == "execute_sql":
                    step["sql"]    = args.get("sql")
                    step["results"]= prev.get("rows", [])
                    step["status"] = prev.get("status", "success")
                else:
                    step["api_call"] = {
                        "method": args.get("method"),
                        "url":    args.get("url"),
                        "params": args.get("params"),
                        "result_preview": prev,
                    }
                trace.append(step)

                # Feed the tool's stringified result back to the LLM.
                messages.append({
                    "role":         "tool",
                    "tool_call_id": tc.get("id", f"call_{total_tool_calls}"),
                    "name":         name,
                    "content":      json.dumps(raw, default=str)[:6000],
                })
        else:
            # Plain text → final answer.
            final_answer = (resp.content or "").strip()
            break

    if final_answer is None:
        # Force a synthesis turn.
        messages.append({
            "role": "user",
            "content": "Based on the evidence above, please give the final concise answer now.",
        })
        resp = llm.chat(messages, tools=None, temperature=0.0, max_tokens=512)
        total_tokens += resp.usage.get("total_tokens", 0)
        final_answer = (resp.content or "").strip()
        turns += 1

    return AgentResult(
        query             = query,
        answer            = final_answer,
        trace             = trace,
        metadata          = ctx,
        filled_prompt     = sys_p,
        turns             = turns,
        total_tool_calls  = total_tool_calls,
        total_tokens      = total_tokens,
        wall_ms           = int((time.time() - t0) * 1000),
    )
