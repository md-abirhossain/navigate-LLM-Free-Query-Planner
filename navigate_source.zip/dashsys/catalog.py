"""Curated catalog of (a) the Knowledge-Graph schema and (b) the Adobe API endpoints.

The catalog is the *only* domain-specific knowledge the agent needs at run time.
Keeping it as a single, structured Python object lets the context-builder do
deterministic retrieval (no extra LLM call) and the agent itself can stay tiny.

### Extending the catalog without editing this file

For enterprise use you almost certainly want to add endpoints, intent
keywords or SQL skeletons over time without touching Python.  This module
merges an optional JSON file at import time:

    $DASHSYS_EXTRAS  (default: ``dashsys/extras.json`` next to this module)

The file may have any of these top-level keys (all optional):

    {
      "entity_keywords": { "tag": ["unified tag", ...] },
      "entity_to_kg":    { "tag": ["dim_tag_local"] },
      "endpoints": [
        {"id": "tags.search", "method": "GET",
         "path": "/unifiedtags/tags/search", "entity": "tag",
         "intent_keywords": ["search tag"], "default_params": {"q": ""}},
        ...
      ]
    }

Existing entries are merged (lists are extended, dicts are updated).  This
gives you a clean, deploy-time extension point for new APIs and intents.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from typing import Dict, List, Optional


# ---------------------------------------------------------------------------
# KG schema  ---------------------------------------------------------------
# ---------------------------------------------------------------------------

# Compact, hand-curated column list per table.  We keep only the columns that
# appeared in the gold SQL queries plus the primary keys / common timestamps.
# Each entry: (column, type, short_doc)

KG_SCHEMA: Dict[str, Dict] = {
    # ---------- dimensions ----------
    "dim_campaign": {
        "entity":  "journey",
        "doc":     "Adobe Journey Optimizer journeys (a.k.a. campaigns). "
                   "STATE='deployed' or 'redeployed' = currently active.",
        "columns": [
            ("CAMPAIGNID",            "VARCHAR", "primary key / journey id"),
            ("NAME",                  "VARCHAR", "journey name"),
            ("STATE",                 "VARCHAR", "draft | deployed | redeployed | stopped"),
            ("STATUS",                "VARCHAR", "internal status"),
            ("CAMPAIGNTYPE",          "VARCHAR", "type"),
            ("LASTDEPLOYEDTIME",      "TIMESTAMP", "when the journey was last published; NULL = never"),
            ("STARTDATE",             "TIMESTAMP", "scheduled start"),
            ("STOPPEDTIME",           "TIMESTAMP", "when stopped"),
            ("FINISHEDTIME",          "TIMESTAMP", "when finished"),
            ("CREATEDTIME",           "VARCHAR",   "created"),
            ("UPDATEDTIME",           "VARCHAR",   "last updated"),
            ("ISSCHEDULED",           "BOOLEAN",   ""),
            ("ISRECURRING",           "BOOLEAN",   ""),
            ("CAMPAIGNACTIVITYCOUNT", "BIGINT",    "number of activities in journey"),
        ],
    },
    "dim_segment": {
        "entity":  "segment",
        "doc":     "Segment / audience definitions.  Each segment may be wired "
                   "to a destination via hkg_br_segment_target.",
        "columns": [
            ("SEGMENTID",       "VARCHAR", "primary key"),
            ("NAME",            "VARCHAR", "segment name"),
            ("DEFINITION",      "VARCHAR", "JSON definition"),
            ("TYPE",            "VARCHAR", "people | account | ..."),
            ("TOTALMEMBERS",    "BIGINT",  "evaluated profile count"),
            ("LIFECYCLESTATUS", "VARCHAR", "lifecycle status"),
            ("ISBATCH",         "BOOLEAN", "batch evaluated"),
            ("ISSTREAMING",     "BOOLEAN", "streaming evaluated"),
            ("ISEDGE",          "BOOLEAN", "edge evaluated"),
            ("ISPEOPLESEGMENT", "BOOLEAN", ""),
            ("MERGEPOLICYID",   "VARCHAR", "FK → merge policy"),
            ("CREATEDTIME",     "VARCHAR", ""),
            ("UPDATEDTIME",     "VARCHAR", ""),
        ],
    },
    "dim_collection": {
        "entity":  "dataset",
        "doc":     "Datasets (a.k.a. collections).  Storage size / row counts "
                   "live here.  Linked to its schema via hkg_br_blueprint_collection.",
        "columns": [
            ("COLLECTIONID",          "VARCHAR", "primary key"),
            ("NAME",                  "VARCHAR", "dataset name"),
            ("ROWCOUNT",              "BIGINT",  ""),
            ("STORAGESIZEINBYTES",    "BIGINT",  ""),
            ("STORAGESIZEINMEGABYTES","DOUBLE",  ""),
            ("ISPROFILEENABLED",      "BOOLEAN", ""),
            ("ISIDENTITYENABLED",     "BOOLEAN", ""),
            ("ISSYSTEM",              "BOOLEAN", ""),
            ("ISTTLSET",              "BOOLEAN", ""),
            ("TTLVALUE",              "VARCHAR", ""),
            ("CREATEDBY",             "VARCHAR", ""),
            ("CREATEDTIME",           "VARCHAR", ""),
            ("UPDATEDBY",             "VARCHAR", ""),
            ("UPDATEDTIME",           "VARCHAR", ""),
        ],
    },
    "dim_blueprint": {
        "entity":  "schema",
        "doc":     "XDM schemas (a.k.a. blueprints).  CLASS holds the parent XDM "
                   "class (e.g. _xdm.context.experienceevent).",
        "columns": [
            ("BLUEPRINTID",            "VARCHAR", "primary key"),
            ("NAME",                   "VARCHAR", "schema name"),
            ("CLASS",                  "VARCHAR", "XDM class, e.g. _xdm.context.experienceevent"),
            ("BLUEPRINTTYPE",          "VARCHAR", "object | ..."),
            ("ISPROFILEENABLED",       "BOOLEAN", "union profile enabled"),
            ("ISBEHAVIORTIMESERIESTYPE","BOOLEAN","ExperienceEvent indicator"),
            ("ISBEHAVIORRECORDTYPE",   "BOOLEAN", "Record indicator"),
            ("DESCRIPTION",            "VARCHAR", ""),
            ("REQUIREDFIELDS",         "VARCHAR", ""),
            ("EXTENDS",                "VARCHAR", ""),
            ("TENANT",                 "VARCHAR", ""),
            ("CREATEDTIME",            "VARCHAR", ""),
            ("UPDATEDTIME",            "VARCHAR", ""),
        ],
    },
    "dim_connector": {
        "entity":  "source",
        "doc":     "Inbound source connectors (a.k.a. dataflows that pull data IN).",
        "columns": [
            ("DATAFLOWID",         "VARCHAR", "primary key"),
            ("DATAFLOWNAME",       "VARCHAR", "human name"),
            ("NAME",               "VARCHAR", ""),
            ("SOURCEID",           "VARCHAR", ""),
            ("CONNECTIONSPECNAME", "VARCHAR", "e.g. amazon-s3"),
            ("STATE",              "VARCHAR", "enabled / disabled / failed"),
            ("CATEGORY",           "VARCHAR", "cloudStorage / database / ..."),
            ("FREQUENCY",          "VARCHAR", ""),
            ("INTERVAL",           "BIGINT",  ""),
            ("DESCRIPTION",        "VARCHAR", ""),
            ("SOURCEACCOUNTNAME",  "VARCHAR", ""),
            ("CREATEDTIME",        "VARCHAR", ""),
            ("UPDATEDTIME",        "VARCHAR", ""),
        ],
    },
    "dim_target": {
        "entity":  "destination",
        "doc":     "Destinations (outbound dataflows).  CONNECTIONSPECID links "
                   "to the destination type.",
        "columns": [
            ("TARGETID",         "VARCHAR", "primary key"),
            ("DATAFLOWNAME",     "VARCHAR", "human name of the outbound flow"),
            ("NAME",             "VARCHAR", "destination type, e.g. amazon-s3"),
            ("STATE",            "VARCHAR", ""),
            ("DESCRIPTION",      "VARCHAR", ""),
            ("CONNECTIONSPECID", "VARCHAR", ""),
            ("FREQUENCY",        "VARCHAR", ""),
            ("INTERVAL",         "BIGINT",  ""),
            ("CREATEDTIME",      "VARCHAR", ""),
            ("UPDATEDTIME",      "VARCHAR", ""),
        ],
    },
    "dim_property": {
        "entity":  "property",
        "doc":     "Individual XDM fields / properties used in schemas/segments/destinations.",
        "columns": [
            ("PROPERTYID",        "VARCHAR", "primary key"),
            ("PROPERTY",          "VARCHAR", "fully-qualified property path"),
            ("TYPE",              "VARCHAR", "data type"),
            ("DESCRIPTION",       "VARCHAR", ""),
            ("ALTDISPLAYTITLE",   "VARCHAR", ""),
            ("ALTDISPLAYDESC",    "VARCHAR", ""),
            ("AUGMENTEDDESC",     "VARCHAR", ""),
            ("AUGMENTEDALIASES",  "VARCHAR", ""),
            ("CREATEDTIME",       "VARCHAR", ""),
            ("UPDATEDTIME",       "VARCHAR", ""),
        ],
    },

    # ---------- bridges ----------
    "br_campaign_segment":       {"entity": "bridge", "doc": "journey ↔ segment", "columns": [("CAMPAIGNID","VARCHAR",""),("SEGMENTID","VARCHAR","")]},
    "hkg_br_blueprint_collection":{"entity":"bridge", "doc": "schema ↔ dataset",  "columns": [("BLUEPRINTID","VARCHAR",""),("COLLECTIONID","VARCHAR","")]},
    "hkg_br_blueprint_property": {"entity": "bridge", "doc": "schema ↔ property", "columns": [("BLUEPRINTID","VARCHAR",""),("PROPERTY","VARCHAR","")]},
    "hkg_br_collection_property":{"entity": "bridge", "doc": "dataset ↔ property","columns": [("COLLECTIONID","VARCHAR",""),("PROPERTY","VARCHAR","")]},
    "hkg_br_collection_segment": {"entity": "bridge", "doc": "dataset ↔ segment", "columns": [("COLLECTIONID","VARCHAR",""),("SEGMENTID","VARCHAR","")]},
    "hkg_br_segment_property":   {"entity": "bridge", "doc": "segment ↔ property","columns": [("SEGMENTID","VARCHAR",""),("PROPERTY","VARCHAR","")]},
    "hkg_br_segment_target":     {"entity": "bridge", "doc": "segment ↔ destination","columns": [("SEGMENTID","VARCHAR",""),("TARGETID","VARCHAR","")]},
    "hkg_br_source_collection":  {"entity": "bridge", "doc": "source ↔ dataset",  "columns": [("DATAFLOWID","VARCHAR",""),("COLLECTIONID","VARCHAR","")]},
    "hkg_br_target_property":    {"entity": "bridge", "doc": "destination ↔ property","columns": [("TARGETID","VARCHAR",""),("PROPERTY","VARCHAR","")]},
    "hkg_br_base_segment_used_by_dependent_segment": {"entity":"bridge","doc":"segment ↔ segment (empty)","columns":[]},
    "hkg_br_property_property":  {"entity": "bridge", "doc": "property ↔ property (empty)", "columns": []},
}


# ---------------------------------------------------------------------------
# API endpoint catalog -----------------------------------------------------
# ---------------------------------------------------------------------------

@dataclass
class Endpoint:
    id: str
    method: str
    path: str
    entity: str
    intent_keywords: List[str]
    accept: str = "application/json"
    default_params: Dict[str, str] = field(default_factory=dict)
    kg_tables: List[str] = field(default_factory=list)
    notes: str = ""
    needs_path_param: Optional[str] = None  # e.g. "{id}"
    is_post: bool = False
    body_skeleton: Optional[Dict] = None


API_CATALOG: List[Endpoint] = [
    # ----- Journeys (AJO) -----
    Endpoint("ajo.journey.list",
             "GET", "/ajo/journey",
             entity="journey",
             intent_keywords=["journey", "journeys", "campaign"],
             default_params={"pageSize": "10"},
             kg_tables=["dim_campaign"],
             notes="Use filter='name==<n>' for a single journey, "
                   "filter='status!=live' for inactive."),

    # ----- Schemas -----
    Endpoint("schema.list",
             "GET", "/data/foundation/schemaregistry/tenant/schemas",
             entity="schema",
             intent_keywords=["schema", "schemas", "xdm"],
             accept="application/vnd.adobe.xed-id+json",
             default_params={"limit": "25"},
             kg_tables=["dim_blueprint"],
             notes="MUST send Accept: application/vnd.adobe.xed-id+json. "
                   "Filter examples: filter=class==ExperienceEvent, "
                   "filter=isProfileEnabled==true"),
    Endpoint("schema.get",
             "GET", "/data/foundation/schemaregistry/tenant/schemas/{id}",
             entity="schema",
             intent_keywords=["schema details", "details for schema", "describe schema"],
             accept="application/vnd.adobe.xed+json",
             kg_tables=["dim_blueprint", "hkg_br_blueprint_property", "hkg_br_blueprint_collection"],
             needs_path_param="schemaId",
             notes="Path-param is the schema $id or altId."),

    # ----- Datasets -----
    Endpoint("dataset.list",
             "GET", "/data/foundation/catalog/dataSets",
             entity="dataset",
             intent_keywords=["dataset", "datasets", "collection"],
             default_params={"limit": "25"},
             kg_tables=["dim_collection"],
             notes="Filter by schema with property=schema.name or filter=schemaName==<n>."),

    # ----- Segments / Audiences -----
    Endpoint("segment.definitions",
             "GET", "/data/core/ups/segment/definitions",
             entity="segment",
             intent_keywords=["segment definition", "segment definitions"],
             default_params={"limit": "100"},
             kg_tables=["dim_segment"]),
    Endpoint("audiences.list",
             "GET", "/data/core/ups/audiences",
             entity="segment",
             intent_keywords=["audience", "audiences"],
             default_params={"limit": "25"},
             kg_tables=["dim_segment", "hkg_br_segment_target"]),
    Endpoint("segment.jobs",
             "GET", "/data/core/ups/segment/jobs",
             entity="segment",
             intent_keywords=["segment job", "segment jobs", "evaluation job"],
             default_params={"limit": "20"},
             notes="Filter by status (e.g. property=status==SUCCEEDED) "
                   "to count processing/queued/succeeded."),

    # ----- Merge policies -----
    Endpoint("merge_policies",
             "GET", "/data/core/ups/config/mergePolicies",
             entity="merge_policy",
             intent_keywords=["merge polic", "default merge", "timestamp ordered"],
             default_params={"limit": "10"}),

    # ----- Destinations / flows -----
    Endpoint("flowservice.flows",
             "GET", "/data/foundation/flowservice/flows",
             entity="flow",
             intent_keywords=["destination", "destinations", "dataflow", "flow", "failed dataflow"],
             default_params={"limit": "20"},
             kg_tables=["dim_target", "dim_connector"],
             notes="property=inheritedAttributes.properties.isDestinationFlow==true "
                   "filters to destination flows.  Use filter=state eq 'failed' for failed."),

    # ----- Audit -----
    Endpoint("audit.events",
             "GET", "/data/foundation/audit/events",
             entity="audit",
             intent_keywords=["audit", "audit event", "recent change", "history", "modified by"],
             default_params={"limit": "20"},
             notes="property=assetType==dataset|segment|destination, "
                   "property=action==create|update|delete."),

    # ----- Tags -----
    Endpoint("tags.list",
             "GET", "/unifiedtags/tags",
             entity="tag",
             intent_keywords=["tag", "tags"],
             default_params={"limit": "100"}),
    Endpoint("tags.get",
             "GET", "/unifiedtags/tags/{id}",
             entity="tag",
             intent_keywords=["tag details", "details of tag"],
             needs_path_param="tagId"),
    Endpoint("tag_category",
             "GET", "/unifiedtags/tagCategory",
             entity="tag",
             intent_keywords=["tag category", "tag categories", "uncategorized"]),

    # ----- Batches -----
    Endpoint("batches.list",
             "GET", "/data/foundation/catalog/batches",
             entity="batch",
             intent_keywords=["batch", "batches", "ingest run"],
             default_params={"limit": "20"},
             notes="status=success|failed|processing  orderBy=desc:created"),
    Endpoint("batches.get",
             "GET", "/data/foundation/catalog/batches/{id}",
             entity="batch",
             intent_keywords=["batch details", "details of batch", "show batch"],
             needs_path_param="batchId"),
    Endpoint("batches.files",
             "GET", "/data/foundation/export/batches/{id}/files",
             entity="batch",
             intent_keywords=["files for batch", "files in batch", "available for download in batch"],
             needs_path_param="batchId"),
    Endpoint("batches.failed",
             "GET", "/data/foundation/export/batches/{id}/failed",
             entity="batch",
             intent_keywords=["failed files for batch", "failed files in batch"],
             needs_path_param="batchId"),

    # ----- Observability -----
    Endpoint("observability.metrics",
             "POST", "/data/infrastructure/observability/insights/metrics",
             entity="observability",
             intent_keywords=["ingestion record", "timeseries", "observability",
                              "record success count", "batch success count",
                              "daily values", "metric"],
             is_post=True,
             body_skeleton={
                 "start": "2026-03-01T00:00:00.000Z",
                 "end":   "2026-04-01T23:59:59.000Z",
                 "granularity": "day",
                 "metrics": [{"name": "<metric>",
                              "filters": [],
                              "aggregator": "sum"}],
             }),
]


# ---------------------------------------------------------------------------
# Entity → KG tables mapping (used by the SQL skeleton builder) ------------
# ---------------------------------------------------------------------------

ENTITY_TO_KG: Dict[str, List[str]] = {
    "journey":      ["dim_campaign", "br_campaign_segment"],
    "segment":      ["dim_segment", "hkg_br_segment_target", "hkg_br_segment_property",
                     "hkg_br_collection_segment"],
    "dataset":      ["dim_collection", "hkg_br_blueprint_collection",
                     "hkg_br_collection_property", "hkg_br_source_collection"],
    "schema":       ["dim_blueprint", "hkg_br_blueprint_collection",
                     "hkg_br_blueprint_property"],
    "source":       ["dim_connector", "hkg_br_source_collection"],
    "destination":  ["dim_target", "hkg_br_segment_target", "hkg_br_target_property"],
    "property":     ["dim_property"],
    "tag":          [],  # only in API
    "merge_policy": [],  # only in API
    "batch":        [],  # only in API
    "audit":        [],  # only in API
    "observability":[],  # only in API
    "flow":         ["dim_target", "dim_connector"],
}


# ---------------------------------------------------------------------------
# Keyword → primary entity ------------------------------------------------
# ---------------------------------------------------------------------------

ENTITY_KEYWORDS: Dict[str, List[str]] = {
    "journey":       ["journey", "journeys", "ajo", "campaign", "campaigns",
                      "published", "deployed", "redeployed"],
    "schema":        ["schema", "schemas", "xdm", "blueprint", "blueprints",
                      "experience event", "experienceevent", "profile-enabled",
                      "profile enabled"],
    "dataset":       ["dataset", "datasets", "collection", "collections"],
    "segment":       ["segment", "segments", "audience", "audiences",
                      "segmentation"],
    "destination":   ["destination", "destinations", "dataflow", "dataflows",
                      "flow", "flows", "outbound"],
    "source":        ["source connector", "source", "sources", "inbound",
                      "ingestion source"],
    "tag":           ["tag", "tags", "labels"],
    "merge_policy":  ["merge policy", "merge policies", "mergepolicy"],
    "batch":         ["batch", "batches", "ingest run"],
    "audit":         ["audit", "audit event", "recent change", "history",
                      "modified by", "modified", "deleted by"],
    "observability": ["timeseries", "observability", "record success count",
                      "batch success count", "metric", "metrics", "daily values"],
    "property":      ["property", "properties", "field", "fields", "attribute"],
}


# ---------------------------------------------------------------------------
# Optional runtime extension --------------------------------------------------
# ---------------------------------------------------------------------------

def _merge_extras() -> None:
    """Merge an optional extras file into the in-process catalog.

    Search order:

      1. ``$DASHSYS_EXTRAS`` env var
      2. ``dashsys/extras.json`` next to this file

    The function is *silent on failure* — a missing or invalid extras file
    must never prevent the agent from starting.
    """
    path = os.environ.get("DASHSYS_EXTRAS") or os.path.join(
        os.path.dirname(__file__), "extras.json"
    )
    if not os.path.isfile(path):
        return
    try:
        with open(path, "r", encoding="utf-8") as f:
            extras = json.load(f)
    except Exception:
        return

    for ent, kws in (extras.get("entity_keywords") or {}).items():
        ENTITY_KEYWORDS.setdefault(ent, [])
        for kw in kws:
            if kw not in ENTITY_KEYWORDS[ent]:
                ENTITY_KEYWORDS[ent].append(kw)

    for ent, tables in (extras.get("entity_to_kg") or {}).items():
        ENTITY_TO_KG.setdefault(ent, [])
        for t in tables:
            if t not in ENTITY_TO_KG[ent]:
                ENTITY_TO_KG[ent].append(t)

    for spec in (extras.get("endpoints") or []):
        try:
            ep = Endpoint(
                id              = spec["id"],
                method          = spec.get("method", "GET"),
                path            = spec["path"],
                entity          = spec.get("entity", ""),
                intent_keywords = list(spec.get("intent_keywords") or []),
                accept          = spec.get("accept", "application/json"),
                default_params  = dict(spec.get("default_params") or {}),
                kg_tables       = list(spec.get("kg_tables") or []),
                notes           = spec.get("notes", ""),
                needs_path_param= spec.get("needs_path_param"),
                is_post         = bool(spec.get("is_post", False)),
                body_skeleton   = spec.get("body_skeleton"),
            )
        except KeyError:
            continue
        # Replace by id if it already exists; otherwise append.
        for i, existing in enumerate(API_CATALOG):
            if existing.id == ep.id:
                API_CATALOG[i] = ep
                break
        else:
            API_CATALOG.append(ep)


_merge_extras()
