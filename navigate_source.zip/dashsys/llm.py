"""Pluggable LLM client.

The system is designed to work with any OpenAI-compatible chat-completions
endpoint that supports tool/function calling.  We tested three:

    * CraftX           – https://api.craftx.corecraftsolutions.com  (gpt-oss 120b)
    * OpenAI Agents    – https://api.openai.com
    * Anthropic via SDK – also supported (see agent.py)

Pick a backend with the LLM_BACKEND environment variable (default: craftx).
"""

from __future__ import annotations

import os
import re
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

import requests


@dataclass
class LlmResponse:
    content: Optional[str]
    tool_calls: List[Dict[str, Any]]
    usage:     Dict[str, int]
    raw:       Dict[str, Any]


class LlmClient:
    """OpenAI-compatible chat-completions client."""

    def __init__(self,
                 endpoint: Optional[str] = None,
                 api_key:  Optional[str] = None,
                 model:    Optional[str] = None,
                 timeout:  int = 120):
        raw_backend = os.environ.get("LLM_BACKEND", "craftx").strip().lower()
        # Accept numeric shortcuts: 0 = craftx, 1 = openai
        backend = {"0": "craftx", "1": "openai"}.get(raw_backend, raw_backend)

        defaults = {
            "craftx": ("https://api.craftx.corecraftsolutions.com/api/v1/chat/completions",
                       "gpt-oss-120b"),
            "openai": ("https://api.openai.com/v1/chat/completions",
                       "gpt-4.1-mini"),
        }
        if backend not in defaults:
            raise RuntimeError(
                f"Unknown LLM_BACKEND={raw_backend!r}. "
                f"Use 0/craftx or 1/openai."
            )
        ep_default, model_default = defaults[backend]
        self.backend  = backend
        self.endpoint = endpoint or os.environ.get("LLM_ENDPOINT", ep_default)
        self.model    = model    or os.environ.get("LLM_MODEL",    model_default)

        # Backend-aware key selection (env-only; never hardcoded).
        if backend == "openai":
            self.api_key = api_key or os.environ.get("OPENAI_API_KEY") \
                                   or os.environ.get("LLM_API_KEY")
        else:
            self.api_key = api_key or os.environ.get("CRAFTX_API_KEY") \
                                   or os.environ.get("LLM_API_KEY")

        if not self.api_key:
            need = "OPENAI_API_KEY" if backend == "openai" else "CRAFTX_API_KEY"
            raise RuntimeError(
                f"Set {need} (or LLM_API_KEY) to use the {backend} backend."
            )
        self.timeout = timeout

    def chat(self,
             messages: List[Dict[str, Any]],
             tools:    Optional[List[Dict]] = None,
             temperature: float = 0.1,
             max_tokens:  int   = 1024) -> LlmResponse:
        payload: Dict[str, Any] = {
            "model":       self.model,
            "messages":    messages,
            "temperature": temperature,
            "max_tokens":  max_tokens,
        }
        if tools:
            payload["tools"]        = tools
            payload["tool_choice"]  = "auto"

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type":  "application/json",
        }
        # Retry on transient 5xx and OpenAI/CraftX rate limits.  The eval
        # scorer runs many agent+judge calls back-to-back, so 429s are common
        # on gpt-4.1 unless we honor the provider's "try again in Xs" hint.
        last_text = ""
        for attempt in range(6):
            r = requests.post(self.endpoint, headers=headers,
                              json=payload, timeout=self.timeout)
            last_text = r.text
            if r.status_code == 429:
                wait = _retry_after_seconds(r.text)
                time.sleep(min(12.0, wait + 0.5 * attempt))
                continue
            if r.status_code < 500:
                break
            time.sleep(1.5 * (attempt + 1))
        if not r.ok:
            raise RuntimeError(f"LLM call failed [{r.status_code}]: {last_text[:400]}")
        data = r.json()
        choice = data["choices"][0]
        msg    = choice.get("message", {})
        return LlmResponse(
            content    = msg.get("content") or msg.get("reasoning"),
            tool_calls = msg.get("tool_calls") or [],
            usage      = data.get("usage", {}),
            raw        = data,
        )


def _retry_after_seconds(text: str) -> float:
    m = re.search(r"try again in ([0-9.]+)s", text, flags=re.I)
    if m:
        return max(1.0, float(m.group(1)))
    m = re.search(r"try again in ([0-9.]+)ms", text, flags=re.I)
    if m:
        return max(1.0, float(m.group(1)) / 1000.0)
    return 5.0
