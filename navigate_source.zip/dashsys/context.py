"""Per-query context builder.

This module implements the *retrieval / planning* step of the agent system.
It takes a natural-language query and produces a compact ``metadata`` dict
that contains:

    * primary entity         – the type of thing the query is about
    * relevant_tables        – KG tables most likely to be useful
    * schema_slice           – pretty-printed schema for those tables
    * candidate_endpoints    – ranked list of API endpoint candidates
    * candidate_sql          – a SQL skeleton ready to be edited by the agent
    * candidate_api_call     – the most likely API call to make
    * few_shot_examples      – 1-2 nearest dev examples (optional)

The agent then needs at most one or two tool calls to finish the job.
Everything in this file is deterministic – no LLM call.  That gives us a
huge efficiency win (zero pre-processing tokens).
"""

from __future__ import annotations

import json
import re
from dataclasses import asdict
from typing import Dict, List, Optional, Tuple

from .catalog import (
    API_CATALOG,
    ENTITY_KEYWORDS,
    ENTITY_TO_KG,
    KG_SCHEMA,
    Endpoint,
)

_QUOTED  = re.compile(r"['\"\u2018\u2019\u201C\u201D\u00AB\u00BB`]([^'\"\u2018\u2019\u201C\u201D\u00AB\u00BB`]{2,})"
                      r"['\"\u2018\u2019\u201C\u201D\u00AB\u00BB`]")
_UUID    = re.compile(r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")
_BATCHID = re.compile(r"\b(?:01[0-9A-Z]{24}|[0-9a-f]{24})\b")
_DATE    = re.compile(r"\b(20\d{2}-\d{2}-\d{2})\b")

# Time-window phrases.  Matches: "last 3 days", "past 48 hours",
# "previous 2 weeks", "in the last month", "over the last 90 days",
# "during the past year", "for the last 6 months", etc.
_LAST_N = re.compile(
    r"(?:in\s+the\s+|over\s+the\s+|during\s+the\s+|for\s+the\s+|within\s+the\s+|the\s+)?"
    r"(?:last|past|previous|recent)\s+"
    r"(\d+|a|an|one|two|three|four|five|six|seven|eight|nine|ten)?\s*"
    r"(hour|hours|day|days|week|weeks|month|months|quarter|quarters|year|years|"
    r"min|mins|minute|minutes)",
    re.I,
)

# Title-Case / capitalised entity-name extractor — catches names that the
# user did NOT enclose in quotes.  Anchored on common preposition words so
# we don't grab the start of every sentence.
_NAME_ANCHOR = re.compile(
    r"(?:"
    r"named|called|for(?: the)?|of(?: the)?|about|on|in|with(?: the)?|"
    r"matching|titled|labelled|labeled"
    r")\s+"
    r"((?:[A-Z][A-Za-z0-9_\-/]*(?:\s*[:#\-/]\s*)?)"            # first word + opt sep
    r"(?:\s+[A-Z0-9][A-Za-z0-9_\-/]*){0,6})",                  # up to 6 more words
)

# Words that look capitalised but are almost never entity names.
_NAME_STOP = {
    "Adobe", "Experience", "Platform", "Journey", "Optimizer",
    "AEP", "AJO", "SQL", "API", "REST", "JSON",
    "I", "The", "Show", "List", "Provide", "Give", "How", "What",
    "When", "Where", "Which", "Who", "Why", "Tell",
    "Sandbox", "Database", "Schema", "Dataset", "Segment", "Destination",
    "Source", "Tag", "Batch",
}


# ----------------------------------------------------------------------------
# 1.  Entity detection ------------------------------------------------------
# ----------------------------------------------------------------------------

_AUDIT_PHRASES = (
    "recent change", "recent changes", "created by", "modified by",
    "deleted by", "audit", "who created", "who modified",
    "show me all entities", "all entities created",
    "in the last 3 month", "in the last 7 day", "in the last 30 day",
    "in the last 90 day", "in the last 6 month", "in the last month",
    "in the past",
)
_OBS_PHRASES = (
    "timeseries", "record success count", "batch success count",
    "daily values", "ingestion record", "observability",
)
# Underlying entities can carry meaningful KG SQL even when an "audit"
# or "observability" modifier is present (e.g. "recent changes in datasets"
# → audit endpoint + dim_collection SQL).
_UNDERLYING_ENTITIES = ("journey", "schema", "dataset", "segment",
                        "destination", "source", "property")


def _lemma_match(kw: str, q: str) -> bool:
    """Match ``kw`` in ``q`` allowing simple plural/singular variants.

    ``q`` is the lowercased query.  The match is whole-word so we don't
    accidentally hit substrings (e.g. "tag" in "stage").
    """
    if " " in kw:                       # multi-token phrases: just substring
        return kw in q
    variants = {kw}
    if kw.endswith("y"):
        variants.add(kw[:-1] + "ies")
    elif kw.endswith("s"):
        variants.add(kw[:-1])
    else:
        variants.add(kw + "s")
    return any(re.search(rf"\b{re.escape(v)}\b", q) for v in variants)


def detect_entity(query: str) -> Tuple[str, float, Optional[str]]:
    """Return ``(primary_entity, confidence, modifier)``.

    ``modifier`` is one of ``None`` / ``"audit"`` / ``"observability"`` and is
    used by ``rank_endpoints`` to add a special "view" endpoint while the
    underlying entity still drives the SQL skeleton.
    """
    q = query.lower()
    scores: Dict[str, int] = {}
    for ent, kws in ENTITY_KEYWORDS.items():
        s = 0
        seen_canon: set = set()
        for kw in kws:
            # Treat "dataset" and "datasets" as the same keyword so plural
            # forms in the catalog don't double-count against singular forms
            # in the query.
            if " " in kw:
                canon = kw
            elif kw.endswith("ies"):
                canon = kw[:-3] + "y"
            elif kw.endswith("s"):
                canon = kw[:-1]
            else:
                canon = kw
            if canon in seen_canon:
                continue
            if _lemma_match(kw, q):
                seen_canon.add(canon)
                s += 5 if " " in kw else 2
        if s:
            scores[ent] = s

    # ------- Subject-noun boost --------------------------------------------
    # The first noun after an interrogative anchor ("how many", "list all",
    # "show me", "count the", …) is almost always the user's primary
    # entity.  Boost any entity whose canonical keyword matches this noun
    # — this resolves singular/plural ambiguities like "how many datasets
    # have been ingested using the same schema" (subject = datasets).
    m = re.search(
        r"(?:how\s+many|list(?:\s+all)?|show\s+me(?:\s+all)?|"
        r"give\s+me(?:\s+all)?|count(?:\s+the)?|display(?:\s+all)?|"
        r"export(?:\s+a\s+list\s+of)?(?:\s+all)?|tell\s+me\s+about|"
        r"provide\s+(?:more\s+)?details\s+for|what\s+are\s+the|"
        r"which(?:\s+\w+)?|find(?:\s+all)?|number\s+of)"
        r"\s+(\w+)",
        q, flags=re.I,
    )
    if m:
        subj = m.group(1).lower().rstrip("s")
        for ent, kws in ENTITY_KEYWORDS.items():
            for kw in kws:
                if " " in kw:
                    continue
                k = kw[:-1] if kw.endswith("s") else kw
                if k == subj or subj.startswith(k) or k.startswith(subj):
                    scores[ent] = scores.get(ent, 0) + 4
                    break

    # "field for <SegmentName>" / "property of <SegmentName>" — almost always
    # means *give me the schema-properties used by that segment*, so the
    # SQL must run on dim_segment + hkg_br_segment_property, not dim_property.
    if (("field" in q or "property" in q or "attribute" in q)
            and any(c == ":" for c in query)
            and "segment" not in q
            and "schema" not in q):
        scores["segment"] = (max(scores.values()) if scores else 0) + 8
        scores.pop("property", None)

    modifier: Optional[str] = None

    # Observability is a *modifier* — but if no other entity matched, treat
    # the question as a pure observability call (POST /…/insights/metrics).
    if any(p in q for p in _OBS_PHRASES):
        modifier = "observability"
        if not any(e in scores for e in _UNDERLYING_ENTITIES):
            scores["observability"] = 100

    # Audit is a *modifier* — boost the audit endpoint, but only crown audit
    # the primary entity when no real underlying asset is mentioned.
    if any(p in q for p in _AUDIT_PHRASES):
        modifier = "audit"
        if not any(e in scores for e in _UNDERLYING_ENTITIES):
            scores["audit"] = (max(scores.values()) if scores else 0) + 6

    if not scores:
        return ("schema", 0.0, modifier)
    ent, score = max(scores.items(), key=lambda kv: kv[1])
    total = sum(scores.values())
    return (ent, score / total, modifier)


# ----------------------------------------------------------------------------
# 2.  Literal / id extraction -----------------------------------------------
# ----------------------------------------------------------------------------

_WORD_TO_NUM = {"a": 1, "an": 1, "one": 1, "two": 2, "three": 3, "four": 4,
                "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9,
                "ten": 10}
_UNIT_HOURS = {"hour": 1/24, "hours": 1/24,
               "min": 1/(24*60), "mins": 1/(24*60),
               "minute": 1/(24*60), "minutes": 1/(24*60),
               "day": 1, "days": 1,
               "week": 7, "weeks": 7,
               "month": 30, "months": 30,
               "quarter": 90, "quarters": 90,
               "year": 365, "years": 365}


def _parse_last_n(match: "re.Match") -> Dict[str, float]:
    raw_n, unit = match.group(1), match.group(2).lower()
    n: float
    if raw_n is None:
        n = 1.0
    elif raw_n.isdigit():
        n = float(raw_n)
    else:
        n = float(_WORD_TO_NUM.get(raw_n.lower(), 1))
    days = n * _UNIT_HOURS.get(unit, 1)
    return {"raw": match.group(0), "n": n, "unit": unit, "days": days}


def extract_literals(query: str) -> Dict[str, List]:
    quoted = _QUOTED.findall(query)

    # Title-Case fallback names (only when no explicit quotes were given,
    # or in addition to them when the anchor is unambiguous).
    fuzzy_names: List[str] = []
    for m in _NAME_ANCHOR.finditer(query):
        cand = m.group(1).strip(" .,:;")
        first = cand.split()[0] if cand else ""
        if cand and first not in _NAME_STOP and len(cand) >= 3:
            fuzzy_names.append(cand)

    time_windows = [_parse_last_n(m) for m in _LAST_N.finditer(query)]

    return {
        "quoted":   quoted,
        "names":    fuzzy_names,
        "uuids":    _UUID.findall(query),
        "batchids": [b for b in _BATCHID.findall(query) if not _UUID.fullmatch(b)],
        "dates":    _DATE.findall(query),
        "time_windows": time_windows,
        # back-compat: keep the original ``last_n`` key as a list of strings
        # so any caller using it still works.
        "last_n":   [tw["raw"] for tw in time_windows],
    }


# ----------------------------------------------------------------------------
# 3.  Endpoint ranking ------------------------------------------------------
# ----------------------------------------------------------------------------

def rank_endpoints(query: str, entity: str, lits: Dict[str, List[str]],
                   modifier: Optional[str] = None) -> List[Endpoint]:
    q = query.lower()
    ranked: List[Tuple[int, Endpoint]] = []
    for ep in API_CATALOG:
        score = 0
        if ep.entity == entity:
            score += 5
        for kw in ep.intent_keywords:
            if kw in q:
                score += 4 if " " in kw else 2
        # Prefer .get variants ONLY when a real id (UUID / batch-id) is in the
        # query.  A quoted *name* should still hit the .list endpoint with a
        # name filter — the gold trajectories follow this convention.
        has_real_id = bool(lits["uuids"] or lits["batchids"])
        if ep.needs_path_param and has_real_id:
            if "batch" in ep.id and lits["batchids"]:
                score += 8
            if "schema" in ep.id and lits["uuids"]:
                score += 8
            if "tag" in ep.id and lits["uuids"]:
                score += 8
        if ep.needs_path_param and not has_real_id:
            # Mildly de-prefer path-param endpoints when no id is available,
            # so the list endpoint wins for "details for <name>" queries.
            score -= 3
        # Specific phrase boosts
        if "failed files" in q and ep.id == "batches.failed":
            score += 10
        if "files" in q and "available" in q and ep.id == "batches.files":
            score += 10
        if "details" in q and ep.needs_path_param and has_real_id:
            score += 4
        if ep.is_post and any(t in q for t in ["between", "last 90 days", "daily values",
                                               "record success count", "batch success count"]):
            score += 6
        # Modifier-driven boosts: when the user is asking about "changes",
        # promote the audit-events endpoint above the underlying entity's
        # list endpoint (e.g. dim_collection list → /data/foundation/audit/events).
        if modifier == "audit" and ep.id == "audit.events":
            score += 20
        if modifier == "observability" and ep.id == "observability.metrics":
            score += 20
        if score:
            ranked.append((score, ep))
    ranked.sort(key=lambda t: -t[0])
    return [ep for _, ep in ranked[:4]]


# ----------------------------------------------------------------------------
# 4.  SQL skeleton builder --------------------------------------------------
# ----------------------------------------------------------------------------

# Manual SQL skeletons keyed by primary entity.  These are the "starting
# points" the agent will mostly want to use.  Each contains a single
# {{filter}} placeholder that the agent fills in.
SQL_SKELETONS: Dict[str, str] = {
    "journey": (
        "SELECT campaignid, name, state, status, lastdeployedtime, "
        "createdtime, updatedtime\n"
        "FROM dim_campaign\n"
        "WHERE {filter}\n"
        "LIMIT 50"
    ),
    "schema": (
        "SELECT blueprintid, name, class, isprofileenabled, isbehaviortimeseriestype,\n"
        "       isbehaviorrecordtype, updatedtime\n"
        "FROM dim_blueprint\n"
        "WHERE {filter}\n"
        "LIMIT 25"
    ),
    "dataset": (
        "SELECT D.collectionid, D.name, D.rowcount, D.storagesizeinbytes,\n"
        "       D.isprofileenabled, D.createdby, D.updatedtime\n"
        "FROM dim_collection AS D\n"
        "WHERE {filter}\n"
        "ORDER BY D.updatedtime DESC\n"
        "LIMIT 25"
    ),
    "segment": (
        "SELECT segmentid, name, type, totalmembers, lifecyclestatus,\n"
        "       ispeoplesegment, isbatch, isstreaming, createdtime, updatedtime\n"
        "FROM dim_segment\n"
        "WHERE {filter}\n"
        "LIMIT 25"
    ),
    "destination": (
        "SELECT targetid, dataflowname, name, state, description,\n"
        "       connectionspecid, createdtime, updatedtime\n"
        "FROM dim_target\n"
        "WHERE {filter}\n"
        "ORDER BY updatedtime DESC\n"
        "LIMIT 25"
    ),
    "source": (
        "SELECT dataflowid, dataflowname, name, sourceid, state,\n"
        "       category, connectionspecname, createdtime, updatedtime\n"
        "FROM dim_connector\n"
        "WHERE {filter}\n"
        "LIMIT 25"
    ),
    "property": (
        "SELECT propertyid, property, type, description, updatedtime\n"
        "FROM dim_property\n"
        "WHERE {filter}\n"
        "LIMIT 25"
    ),
}

# Multi-table joins for cross-entity queries (e.g. "segments → destination").
JOIN_SKELETONS: Dict[Tuple[str, str], str] = {
    ("segment", "destination"): (
        "SELECT a.segmentid, a.name AS segment_name,\n"
        "       d.targetid, d.dataflowname AS destination_name,\n"
        "       a.totalmembers, a.createdtime, a.updatedtime\n"
        "FROM dim_segment a\n"
        "JOIN hkg_br_segment_target ad ON a.segmentid = ad.segmentid\n"
        "JOIN dim_target d ON ad.targetid = d.targetid\n"
        "WHERE {filter}"
    ),
    ("dataset", "schema"): (
        "SELECT D.collectionid, D.name AS dataset_name,\n"
        "       S.blueprintid, S.name AS schema_name\n"
        "FROM dim_collection D\n"
        "JOIN hkg_br_blueprint_collection SD ON D.collectionid = SD.collectionid\n"
        "JOIN dim_blueprint S ON SD.blueprintid = S.blueprintid\n"
        "WHERE {filter}\n"
        "LIMIT 25"
    ),
    ("schema", "dataset"): (
        "SELECT S.blueprintid, S.name AS schema_name,\n"
        "       COUNT(DISTINCT SD.collectionid) AS dataset_count\n"
        "FROM dim_blueprint S\n"
        "LEFT JOIN hkg_br_blueprint_collection SD ON S.blueprintid = SD.blueprintid\n"
        "WHERE {filter}\n"
        "GROUP BY S.blueprintid, S.name"
    ),
    ("segment", "property"): (
        "SELECT DISTINCT sp.property, s.name AS segment_name\n"
        "FROM hkg_br_segment_property sp\n"
        "JOIN dim_segment s ON sp.segmentid = s.segmentid\n"
        "WHERE {filter}\n"
        "LIMIT 25"
    ),
}


# Tables + primary key per entity (used for COUNT and id-match WHERE clauses).
_ENTITY_TABLE = {
    "journey":     ("dim_campaign",   "campaignid"),
    "schema":      ("dim_blueprint",  "blueprintid"),
    "dataset":     ("dim_collection", "collectionid"),
    "segment":     ("dim_segment",    "segmentid"),
    "destination": ("dim_target",     "targetid"),
    "source":      ("dim_connector",  "dataflowid"),
    "property":    ("dim_property",   "propertyid"),
}


def build_sql_skeleton(entity: str, lits: Dict[str, List[str]], query: str) -> Optional[str]:
    q = query.lower()

    # ---------- COUNT skeletons --------------------------------------------
    # When the user asks "how many …" / "count …", a single COUNT(DISTINCT …)
    # query is dramatically closer to the gold SQL than a list-and-filter.
    if (q.startswith("how many") or q.startswith("count ")
            or q.startswith("count the") or "how many" in q
            or q.startswith("number of") or "what is the number of" in q):
        meta = _ENTITY_TABLE.get(entity)
        if meta:
            tbl, pk = meta
            extras: List[str] = []
            if entity == "schema":
                if "experience event" in q or "experienceevent" in q:
                    extras.append("LOWER(CLASS) LIKE '%experienceevent%'")
                if "profile" in q and "enabled" in q:
                    extras.append("ISPROFILEENABLED = TRUE")
            if entity == "dataset" and ("same schema" in q):
                # Count datasets grouped by schema, keeping only those
                # whose schema is shared by more than one dataset.
                return ("SELECT S.blueprintid AS blueprint_id,\n"
                        "       S.name AS blueprint_name,\n"
                        "       COUNT(DISTINCT DS.collectionid) AS collection_count\n"
                        "FROM dim_collection AS D\n"
                        "JOIN hkg_br_blueprint_collection AS DS ON D.collectionid = DS.collectionid\n"
                        "JOIN dim_blueprint AS S ON DS.blueprintid = S.blueprintid\n"
                        "GROUP BY S.blueprintid, S.name\n"
                        "HAVING COUNT(DISTINCT DS.collectionid) > 1")
            where = (" WHERE " + " AND ".join(extras)) if extras else ""
            return f"SELECT COUNT(DISTINCT {pk}) AS {entity}_count\nFROM {tbl}{where}"

    # ---------- Cross-entity JOIN skeletons --------------------------------
    if entity == "segment" and any(x in q for x in ["destination", "target", "sms opt"]):
        pair = ("segment", "destination")
    elif entity == "dataset" and ("schema" in q or "blueprint" in q):
        pair = ("dataset", "schema")
    elif entity == "schema" and ("dataset" in q or "collection" in q):
        pair = ("schema", "dataset")
    elif entity == "segment" and ("field" in q or "property" in q or "attribute" in q):
        pair = ("segment", "property")
    else:
        pair = None

    if pair and pair in JOIN_SKELETONS:
        tmpl = JOIN_SKELETONS[pair]
    else:
        tmpl = SQL_SKELETONS.get(entity)
        if not tmpl:
            return None

    # ---------- Build the WHERE filter -------------------------------------
    parts: List[str] = []
    names = list(lits["quoted"])
    # Fall back to Title-Case fuzzy names when no explicit quotes were given.
    if not names and lits.get("names"):
        names = lits["names"][:2]
    for n in names:
        safe = n.replace("'", "''")
        parts.append(f"LOWER(name) = LOWER('{safe}')")
    if lits["uuids"]:
        meta = _ENTITY_TABLE.get(entity)
        if meta:
            parts.append(f"{meta[1]} = '{lits['uuids'][0]}'")
    # Lifecycle / state filters
    if entity == "journey":
        if "inactive" in q or "not active" in q or "stopped" in q:
            parts.append("LOWER(state) NOT IN ('deployed', 'redeployed')")
        elif "active" in q or "live" in q or "deployed" in q:
            parts.append("LOWER(state) IN ('deployed', 'redeployed')")
    if entity == "source" and "failed" in q:
        parts.append("LOWER(state) = 'failed'")
    if entity == "dataset" and "created by download" in q:
        parts.append("createdby ILIKE '%download%'")

    if not parts:
        parts.append("1=1")
    return tmpl.format(filter=" AND ".join(parts) if len(parts) > 1 else parts[0])


# ----------------------------------------------------------------------------
# 5.  Build candidate API call ----------------------------------------------
# ----------------------------------------------------------------------------

def build_api_call(ep: Endpoint, query: str, lits: Dict[str, List[str]]) -> Dict:
    """Concrete request the agent can fire as-is."""
    path = ep.path
    params = dict(ep.default_params)

    # Substitute the path-param placeholder when an id was extracted.
    if ep.needs_path_param:
        ident: Optional[str] = None
        if ep.needs_path_param == "batchId" and lits["batchids"]:
            ident = lits["batchids"][0]
        elif lits["uuids"]:
            ident = lits["uuids"][0]
        elif lits.get("quoted"):
            ident = lits["quoted"][0]
        if ident:
            path = path.replace("{id}", ident)

    # Per-endpoint param heuristics --------------------------------------
    q = query.lower()
    # Prefer explicit quoted names; otherwise fall back to fuzzy Title-Case
    # names extracted from anchor phrases ("named X", "for the schema X",
    # "of the segment X", etc.).
    name_lit: Optional[str] = None
    if lits.get("quoted"):
        name_lit = lits["quoted"][0]
    elif lits.get("names"):
        name_lit = lits["names"][0]

    if ep.id == "ajo.journey.list":
        if name_lit:
            params = {"filter": f"name=={name_lit}"}
        elif "inactive" in q or "not active" in q or "stopped" in q:
            params = {"filter": "status!=live"}
        elif "active" in q or "live" in q:
            params = {"filter": "status==live"}

    elif ep.id == "schema.list":
        flts: List[str] = []
        if "experience event" in q or "experienceevent" in q:
            flts.append("class==ExperienceEvent")
        if "profile" in q and "enabled" in q:
            flts.append("isProfileEnabled==true")
        if name_lit:
            flts.append(f"name=={name_lit}")
        if flts:
            params["filter"] = ";".join(flts)

    elif ep.id == "dataset.list":
        if name_lit:
            params["filter"] = f'schemaName=="{name_lit}"'
        elif "same schema" in q:
            params["property"] = "schema.name"

    elif ep.id == "audiences.list":
        if "destination" in q and lits["uuids"]:
            params = {"property": f"destinationId=={lits['uuids'][0]}", "limit": "25"}

    elif ep.id == "flowservice.flows":
        if "failed" in q:
            params = {"filter": "state eq 'failed'", "limit": "50"}
        elif "destination" in q:
            params = {"property": "inheritedAttributes.properties.isDestinationFlow==true",
                      "limit": "25"}
            if "recently modified" in q or "most recent" in q:
                params["sort"] = "updatedTime:desc"

    elif ep.id == "audit.events":
        if "dataset" in q:
            params["property"] = "assetType==dataset"
        elif "destination" in q:
            params["property"] = "assetType==destination"
        elif "segment" in q or "audience" in q:
            params["property"] = "assetType==segment"
        if "created" in q:
            params["property"] = (params.get("property", "") + ";" if "property" in params else "") + \
                                 "action==create"
        if "delete" in q:
            params["property"] = (params.get("property", "") + ";" if "property" in params else "") + \
                                 "action==delete"
        params.setdefault("orderBy", "-timestamp")

    elif ep.id == "segment.jobs":
        if "queued" in q:
            params["property"] = "status==QUEUED"
        elif "processing" in q:
            params["property"] = "status==PROCESSING"
        elif "succeeded" in q or "success" in q:
            params["property"] = "status==SUCCEEDED"
        elif "failed" in q:
            params["property"] = "status==FAILED"

    elif ep.id == "batches.list":
        if "success" in q:
            params["status"] = "success"
        if "failed" in q:
            params["status"] = "failed"
        if "processing" in q:
            params["status"] = "processing"
        if "recent" in q or "most recently" in q:
            params["orderBy"] = "desc:created"

    elif ep.id == "segment.definitions":
        if "most recent" in q or "updated most recently" in q:
            params["orderBy"] = "updateTime:desc"
            params["limit"] = "10"

    # Observability body ------------------------------------------------
    body: Optional[Dict] = None
    if ep.is_post:
        body = json.loads(json.dumps(ep.body_skeleton))  # deep copy
        if "ingestion record" in q or "record success count" in q:
            body["metrics"][0]["name"] = "timeseries.ingestion.dataset.recordsuccess.count"
        if "batch success count" in q or "batches success" in q:
            body["metrics"].append({"name": "timeseries.ingestion.dataset.batchsuccess.count",
                                    "filters": [], "aggregator": "sum"})
        # date range
        if lits["dates"]:
            ds = sorted(lits["dates"])
            body["start"] = f"{ds[0]}T00:00:00.000Z"
            body["end"]   = f"{ds[-1]}T23:59:59.000Z"

    call = {
        "method": ep.method,
        "url":    f"https://platform.adobe.io{path}",
        "params": params,
        "accept": ep.accept,
    }
    if body is not None:
        call["body"] = body
    return call


# ----------------------------------------------------------------------------
# 6.  Schema slice renderer -------------------------------------------------
# ----------------------------------------------------------------------------

def render_schema_slice(tables: List[str]) -> str:
    out: List[str] = []
    for t in tables:
        info = KG_SCHEMA.get(t)
        if not info:
            continue
        cols = ", ".join(f"{c[0]}:{c[1]}" for c in info["columns"][:14])
        out.append(f"  - {t}  // {info['doc']}\n      {cols}")
    return "\n".join(out)


# ----------------------------------------------------------------------------
# 7.  Public entry point ----------------------------------------------------
# ----------------------------------------------------------------------------

# Endpoints that represent live API-only resources.  When one of these is the
# *primary* endpoint we suppress the SQL skeleton entirely — running SQL would
# only hurt the efficiency score without contributing new information.
API_ONLY_PRIMARY_IDS = {
    "segment.definitions", "segment.jobs",
    "merge_policies",
    "tags.list", "tags.get", "tag_category",
    "batches.list", "batches.get", "batches.files", "batches.failed",
    "observability.metrics",
}


def build_context(query: str) -> Dict:
    entity, conf, modifier = detect_entity(query)
    lits         = extract_literals(query)
    ranked_eps   = rank_endpoints(query, entity, lits, modifier=modifier)

    primary_ep   = ranked_eps[0] if ranked_eps else None
    rel_tables   = list(ENTITY_TO_KG.get(entity, []))
    if primary_ep:
        for t in primary_ep.kg_tables:
            if t not in rel_tables:
                rel_tables.append(t)

    # SQL skeleton: build for the *underlying* entity even when an audit /
    # observability modifier is in play, so the agent can validate the live
    # API response against the local KG snapshot (matches gold trajectories).
    sql_skel    = build_sql_skeleton(entity, lits, query)
    if primary_ep and primary_ep.id in API_ONLY_PRIMARY_IDS:
        sql_skel = None

    api_call    = build_api_call(primary_ep, query, lits) if primary_ep else None

    return {
        "query":             query,
        "primary_entity":    entity,
        "entity_confidence": round(conf, 3),
        "modifier":          modifier,
        "literals":          lits,
        "relevant_tables":   rel_tables,
        "schema_slice":      render_schema_slice(rel_tables),
        "candidate_endpoints": [
            {"id": ep.id, "method": ep.method, "path": ep.path,
             "accept": ep.accept, "notes": ep.notes}
            for ep in ranked_eps
        ],
        "candidate_sql":      sql_skel,
        "candidate_api_call": api_call,
    }
