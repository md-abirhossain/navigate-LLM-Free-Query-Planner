"""End-to-end smoke test (no LLM).

Pretends the LLM picked the deterministic plan and just executes that plan
against the real DuckDB + Adobe API.  Confirms that:

  * execute_sql actually runs
  * call_api authenticates and returns real data
  * the trajectory JSON has the right shape
"""

from __future__ import annotations

import io
import json
import os
import sys
import time

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

from dashsys.context import build_context
from dashsys.tools   import execute_sql, call_api


SMOKE_QUERIES = [
    "List all journeys",
    "How many schemas do I have?",
    "List all segment definitions.",
    "List all merge policies in this sandbox.",
    "How many batches have status 'success'?",
    "Show the default merge policy for schema class '_xdm.context.profile'.",
]


def step_from_call(call: dict, raw: dict, idx: int) -> dict:
    return {
        "step":   idx,
        "action": "api_call",
        "api_call": {
            "method": call["method"],
            "url":    call["url"],
            "params": call.get("params"),
            "result_preview": {
                "http_status": raw.get("http_status"),
                "keys":        list(raw["result"].keys())[:6]
                                if isinstance(raw.get("result"), dict) else None,
                "len":         len(raw["result"])
                                if isinstance(raw.get("result"), list) else None,
            },
        },
    }


def main() -> None:
    out = {}
    for q in SMOKE_QUERIES:
        print("=" * 72)
        print("Q:", q)
        ctx  = build_context(q)
        traj = []
        step = 0

        # 1. Run candidate SQL when it makes sense.
        if ctx.get("candidate_sql") and ctx["primary_entity"] not in (
            "merge_policy", "tag", "batch", "audit", "observability"
        ):
            step += 1
            sql = ctx["candidate_sql"]
            print(f"  → SQL  : {sql[:80]}...")
            res = execute_sql(sql)
            traj.append({
                "step":   step,
                "action": "sql_query",
                "sql":    sql,
                "status": res.get("status"),
                "row_count": res.get("row_count"),
                "results": res.get("rows", [])[:3],
            })

        # 2. Run candidate API call.
        if ctx.get("candidate_api_call"):
            step += 1
            call = ctx["candidate_api_call"]
            print(f"  → API  : {call['method']} {call['url']} params={call['params']}")
            raw  = call_api(
                method = call["method"],
                url    = call["url"],
                params = call.get("params"),
                body   = call.get("body"),
                accept = call.get("accept", "application/json"),
            )
            print(f"     status={raw.get('http_status')}  "
                  f"keys={list(raw.get('result', {}).keys())[:5] if isinstance(raw.get('result'), dict) else type(raw.get('result')).__name__}")
            traj.append(step_from_call(call, raw, step))

        out[q] = traj

    with open("smoke_results.json", "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2, default=str)
    print("\nSaved smoke_results.json")


if __name__ == "__main__":
    main()
