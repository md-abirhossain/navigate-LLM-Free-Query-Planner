"""CLI: run a single query end-to-end and emit the four required deliverables.

  python run_one.py "List all journeys" --out outputs/q01
"""

from __future__ import annotations

import argparse
import json
import os
import pathlib

from dashsys.agent  import run_agent
from dashsys.llm    import LlmClient


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("query")
    ap.add_argument("--out",          default="outputs/run")
    ap.add_argument("--snapshot-dir", default="DBSnapshot")
    ap.add_argument("--max-turns",    type=int, default=4)
    ap.add_argument("--verbose",      action="store_true")
    args = ap.parse_args()

    pathlib.Path(args.out).mkdir(parents=True, exist_ok=True)
    llm = LlmClient()

    result = run_agent(args.query, snapshot_dir=args.snapshot_dir,
                       max_turns=args.max_turns, llm=llm, verbose=args.verbose)

    # ---- Deliverable 1: metadata JSON --------------------------------------
    with open(f"{args.out}/metadata.json", "w", encoding="utf-8") as f:
        json.dump(result.metadata, f, indent=2)

    # ---- Deliverable 2: filled system prompt -------------------------------
    with open(f"{args.out}/system_prompt.filled.txt", "w", encoding="utf-8") as f:
        f.write(result.filled_prompt)

    # ---- Deliverable 3: trajectory JSON ------------------------------------
    traj = {
        "query":            result.query,
        "trace":            result.trace,
        "answer":           result.answer,
        "stats": {
            "turns":            result.turns,
            "total_tool_calls": result.total_tool_calls,
            "total_tokens":     result.total_tokens,
            "wall_ms":          result.wall_ms,
        },
    }
    with open(f"{args.out}/trajectory.json", "w", encoding="utf-8") as f:
        json.dump(traj, f, indent=2)

    # ---- Brief stdout summary ---------------------------------------------
    print("=" * 70)
    print(f"Query : {result.query}")
    print(f"Answer: {result.answer}")
    print(f"Stats : turns={result.turns}  tool_calls={result.total_tool_calls} "
          f"tokens={result.total_tokens}  wall={result.wall_ms}ms")
    print(f"Wrote 3 files to {args.out}/")


if __name__ == "__main__":
    main()
