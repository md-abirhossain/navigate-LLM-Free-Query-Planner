"""Offline (LLM-free) evaluator.

For every dev example we compare the pre-computed plan produced by
``dashsys.context.build_context`` to the gold trajectory:

  - api_endpoint_recall     :  was the gold endpoint inside our top-K candidates?
  - sql_table_recall        :  did our candidate SQL touch the same primary table?
  - one_call_routing_rate   :  fraction of gold-1-step examples we routed correctly
                              with the *single* highest-ranked candidate

This lets us iterate on the catalog without burning LLM tokens.
"""

from __future__ import annotations

import json
import re
import sys
from collections import Counter
from urllib.parse import urlparse, parse_qsl

from dashsys.context import build_context


_ID_RE = re.compile(r"^(?:[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"
                    r"|01[0-9A-Z]{24}|[0-9a-f]{24})$")

_PATH_ALIASES = {
    "/schemas":                      "/data/foundation/schemaregistry/tenant/schemas",
    "/audit/events":                 "/data/foundation/audit/events",
    "/data/infrastructure/observability/insights/{id}":
        "/data/infrastructure/observability/insights/metrics",
}

def _strip_path(url: str) -> str:
    if url.startswith("GET ") or url.startswith("POST "):
        url = url.split(" ", 1)[1]
    # strip body=...
    if " body=" in url:
        url = url.split(" body=", 1)[0]
    url = url.split("?", 1)[0]
    if url.startswith("https://platform.adobe.io"):
        url = url[len("https://platform.adobe.io"):]
    # normalise ids – only segments that *look* like IDs
    out = []
    for p in url.strip("/").split("/"):
        if _ID_RE.match(p):
            out.append("{id}")
        else:
            out.append(p)
    norm = "/" + "/".join(out)
    return _PATH_ALIASES.get(norm, norm).lower()


def _first_table(sql: str) -> str:
    m = re.search(r"\bFROM\s+(\w+)", sql or "", flags=re.I)
    return (m.group(1) or "").lower() if m else ""


def main():
    with open("data.json", "r", encoding="utf-8") as f:
        raw = json.load(f)

    n              = len(raw)
    top1_endpoint  = 0
    topk_endpoint  = 0
    table_match    = 0
    one_call_ok    = 0
    expected_1call = 0

    misses = []

    for ex in raw:
        ctx  = build_context(ex["query"])
        gold_apis = ex.get("gold_api") or []

        # ----- endpoint match -----
        gold_paths = set()
        for ga in gold_apis:
            if isinstance(ga, str):
                gold_paths.add(_strip_path(ga))
            elif isinstance(ga, dict):
                gold_paths.add(_strip_path(ga.get("url", "")))

        cand_paths = []
        for ep in ctx["candidate_endpoints"]:
            cand_paths.append(_strip_path(ep["path"]))
        # Normalise gold paths through the same alias map.
        gold_paths = {_strip_path(p) for p in gold_paths}

        if cand_paths:
            if cand_paths[0] in gold_paths:
                top1_endpoint += 1
            if any(p in gold_paths for p in cand_paths):
                topk_endpoint += 1
            else:
                misses.append((ex["query"], cand_paths[:3], list(gold_paths)))

        # ----- SQL table match -----
        gold_sql = ex.get("gold_sql")
        if isinstance(gold_sql, list):
            gold_sql = gold_sql[0] if gold_sql else ""
        gold_tbl = _first_table(gold_sql or "")
        cand_tbl = _first_table(ctx.get("candidate_sql") or "")
        if gold_tbl and gold_tbl == cand_tbl:
            table_match += 1

        # ----- one-call routing rate -----
        actions = [s.get("action") for s in ex.get("trace", [])]
        if actions == ["api_call"]:
            expected_1call += 1
            if cand_paths and cand_paths[0] in gold_paths:
                one_call_ok += 1

    print(f"Examples                       : {n}")
    print(f"API endpoint top-1 accuracy    : {top1_endpoint}/{n}  ({top1_endpoint/n:.0%})")
    print(f"API endpoint top-K (K=4) recall: {topk_endpoint}/{n}  ({topk_endpoint/n:.0%})")
    print(f"Gold-SQL primary-table match   : {table_match}/{n}  ({table_match/n:.0%})")
    print(f"1-call route correct           : {one_call_ok}/{expected_1call}")

    # top-1 misses
    print("\nTop-1 misses:")
    for ex in raw:
        ctx  = build_context(ex["query"])
        gold_apis = ex.get("gold_api") or []
        gold_paths = {_strip_path(ga if isinstance(ga, str) else ga.get("url", ""))
                      for ga in gold_apis}
        cand_paths = [_strip_path(ep["path"]) for ep in ctx["candidate_endpoints"]]
        if cand_paths and cand_paths[0] not in gold_paths:
            print(f"  Q: {ex['query'][:80]}")
            print(f"     pred: {cand_paths[0]}")
            print(f"     gold: {list(gold_paths)}")

    if misses and "--show-misses" in sys.argv:
        print(f"\n{len(misses)} top-K misses:")
        for q, cand, gold in misses[:25]:
            print(f"  Q: {q}")
            print(f"     cand : {cand}")
            print(f"     gold : {gold}")


if __name__ == "__main__":
    main()
