"""Deterministic, LLM-free trajectory generator.

This is what the agent would do *if* the LLM perfectly followed the plan in the
system prompt.  It produces the full submission-shape JSON for every query in
data.json, plus an aggregate stats file.

Run this on machines that cannot reach the LLM endpoint, or for fast offline
regression testing.  It is *not* the final agent; it is a faithful lower-bound
simulation of the planner.

  python run_deterministic.py --queries data.json --out outputs/dev
"""

from __future__ import annotations

import argparse
import io
import json
import os
import pathlib
import sys
import time

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

from dashsys.context import build_context
from dashsys.prompt  import fill_system_prompt
from dashsys.tools   import call_api, execute_sql


# ---------------------------------------------------------------------------
def synthesise_answer(query: str, ctx: dict, steps: list) -> str:
    """Tiny rule-based answer synthesiser so we can score correctness offline."""
    sql_step = next((s for s in steps if s["action"] == "sql_query"), None)
    api_step = next((s for s in steps if s["action"] == "api_call"),  None)

    pieces = []
    if sql_step:
        rc = sql_step.get("row_count", 0)
        pieces.append(f"The SQL query returned {rc} row(s).")
    if api_step:
        rp = api_step["api_call"].get("result_preview", {}) or {}
        status = rp.get("http_status")
        pieces.append(f"The API returned HTTP {status}.")
    if not pieces:
        return "No tool calls were necessary."
    return " ".join(pieces) + "  (Detailed answer would be synthesised by the LLM at run time.)"


def run_one(query: str, snapshot_dir: str, do_api: bool = True) -> dict:
    t0  = time.time()
    ctx = build_context(query)

    steps = []

    # ---------- SQL ----------
    if ctx.get("candidate_sql") and ctx["primary_entity"] not in (
        "merge_policy", "tag", "batch", "audit", "observability"
    ):
        res = execute_sql(ctx["candidate_sql"])
        steps.append({
            "step":      len(steps) + 1,
            "action":    "sql_query",
            "sql":       ctx["candidate_sql"],
            "status":    res.get("status"),
            "row_count": res.get("row_count"),
            "results":   res.get("rows", [])[:3],
        })

    # ---------- API ----------
    if ctx.get("candidate_api_call") and do_api:
        call = ctx["candidate_api_call"]
        try:
            raw  = call_api(
                method = call["method"],
                url    = call["url"],
                params = call.get("params"),
                body   = call.get("body"),
                accept = call.get("accept", "application/json"),
            )
        except Exception as e:
            raw = {"status": "error", "error": str(e)}

        result = raw.get("result")
        preview = {
            "http_status": raw.get("http_status"),
            "keys":  list(result.keys())[:6]  if isinstance(result, dict) else None,
            "len":   len(result)              if isinstance(result, list) else None,
            "sample": (list(result.items())[:1] if isinstance(result, dict)
                       else (result[:1] if isinstance(result, list) else result)),
        }
        steps.append({
            "step":   len(steps) + 1,
            "action": "api_call",
            "api_call": {
                "method": call["method"],
                "url":    call["url"],
                "params": call.get("params"),
                "result_preview": preview,
            },
        })

    return {
        "query":         query,
        "trace":         steps,
        "answer":        synthesise_answer(query, ctx, steps),
        "metadata":      ctx,
        "filled_prompt": fill_system_prompt(query, ctx),
        "stats": {
            "turns":            len(steps),  # deterministic = no LLM turns
            "total_tool_calls": len(steps),
            "wall_ms":          int((time.time() - t0) * 1000),
        },
    }


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--queries", default="data.json",
                    help="path to a data.json-style file OR a single query")
    ap.add_argument("--out",     default="outputs/dev")
    ap.add_argument("--snapshot-dir", default="DBSnapshot")
    ap.add_argument("--no-api",  action="store_true", help="skip live API calls")
    ap.add_argument("--limit",   type=int, default=None)
    args = ap.parse_args()

    pathlib.Path(args.out).mkdir(parents=True, exist_ok=True)

    # Load queries
    if os.path.isfile(args.queries):
        with open(args.queries, "r", encoding="utf-8") as f:
            data = json.load(f)
        queries = [(i, ex["query"], ex) for i, ex in enumerate(data)]
    else:
        queries = [(0, args.queries, None)]

    if args.limit:
        queries = queries[:args.limit]

    summary = []
    for i, q, gold in queries:
        out = run_one(q, args.snapshot_dir, do_api=not args.no_api)

        # Write per-query files
        qdir = pathlib.Path(args.out) / f"q{i:02d}"
        qdir.mkdir(exist_ok=True)
        (qdir / "metadata.json").write_text(json.dumps(out["metadata"], indent=2, default=str),
                                            encoding="utf-8")
        (qdir / "system_prompt.filled.txt").write_text(out["filled_prompt"], encoding="utf-8")
        (qdir / "trajectory.json").write_text(json.dumps({
            "query":  out["query"],
            "trace":  out["trace"],
            "answer": out["answer"],
            "stats":  out["stats"],
        }, indent=2, default=str), encoding="utf-8")

        # Aggregate
        gold_api = (gold or {}).get("gold_api") or []
        gold_sql = (gold or {}).get("gold_sql") or ""
        summary.append({
            "i":             i,
            "query":         q,
            "primary_entity":out["metadata"]["primary_entity"],
            "n_steps":       len(out["trace"]),
            "wall_ms":       out["stats"]["wall_ms"],
            "gold_n_steps":  len((gold or {}).get("trace") or []),
            "ok":            True,
        })
        print(f"[{i:02d}] steps={len(out['trace'])} "
              f"entity={out['metadata']['primary_entity']:14} "
              f"wall_ms={out['stats']['wall_ms']:5}  q={q[:60]}")

    with open(pathlib.Path(args.out) / "summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    print(f"\nWrote {len(summary)} query folders to {args.out}/")


if __name__ == "__main__":
    main()
